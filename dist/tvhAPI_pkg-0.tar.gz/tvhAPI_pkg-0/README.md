# tvh-api

Collecting some simple python interactions with the tvheadend api.
